1. Ensure java is on the PATH
2. cd into the plc_server-0.0.1-SNAPSHOT directory
3. Make appropriate changes to config/plc-configuration.xml
4. Execute run.bat